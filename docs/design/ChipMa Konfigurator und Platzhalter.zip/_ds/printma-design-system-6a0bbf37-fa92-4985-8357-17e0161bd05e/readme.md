# PrintMa Design System

PrintMa GbR is a small 3D-printing service bureau based in **Engen (Hegau), Baden-Württemberg, Germany**. The core product is an online **STL-to-order configurator**: customers upload a 3D model, choose material/colour/print settings, see a live price, and check out — plus supporting marketing pages (materials, services, FAQ, legal).

This design system is a **refinement** of the existing product, not a reskin. The live app's black + gold identity is correct and stays; what changes is execution — the source code leans on heavy gradients-on-everything, glowing coloured shadows, backdrop-blur on every panel, ✓-bullet lists and translateY hover lifts on every card. This system keeps the brand DNA (black surfaces, Inter, restrained gold accent) and strips the "plump" decoration so it reads as professional and clean.

## Sources
- Codebase: `Konfigurator PrintMa/` (React 18 + Vite client, `client/src/...`), mounted read-only. Key files read: `index.css`, `App.css`, `styles/tailwind.css` (shadcn token bridge), `components/Header.jsx|css`, `Footer.jsx|css`, `HomeContent.jsx|css`, `MaterialPage.css`, `ProgressBar.jsx|css`, `PriceDisplay.jsx|css`, `Toast.css`, `AuthModal.css`, `MultiFileUpload.css`, `CartReview.jsx`, `pages/ConfiguratorPage.jsx`, `utils/colorMapping.js`, `components/ui/button.jsx` (shadcn button + cva variants).
- Uploaded logo files: `uploads/PrintMa GbR *.png` (black/white, round/square, transparent lockups) — copied into `assets/logo/`.
- No Figma file was attached.

## What PrintMa sells
Materials: **PLA, PETG, TPU, ASA, ABS, ABS-GF** — filaments in ~20+ colours (PLA has the widest range). Services: FDM 3D printing, CAD-Konstruktion (design services), prototyping, small-batch runs. Shipping: pickup in Engen, standard (3–5 Werktage), express. Region served: Hegau / Bodensee, all of Germany, AT/CH on request.

## Content fundamentals
- **Language**: German only (`de`), formal **Sie**-form throughout — no informal *Du*.
- **Voice**: direct and technical-professional, short benefit statements over storytelling. Headlines state the benefit ("Warum PrintMa für Ihren 3D-Druck?"); body copy is feature + benefit pairs ("Umweltfreundlich, einfach zu drucken").
- **Structure**: numbered step explanations for processes ("1) STL hochladen 2) Material wählen …"), ✓-style benefit lists for feature sets — in this system rendered as a plain check icon + text row, not a bare `✓` glyph.
- **Numbers matter**: exact specs are always stated — layer heights (0.1/0.2/0.3mm), quantity-discount tiers (5–10 Teile: 10%, 11–25: 15%…), delivery windows (2–5 Werktage). Never vague ("schnell") without a number nearby.
- **No emoji** in UI copy or headings (the source has one stray 📦/✓ decorative use in older code — treat as legacy, not a pattern to continue).
- **Trust/local signals**: physical address, email, and named towns (Engen, Singen, Konstanz…) appear often — locality is part of the brand's credibility.

## Visual foundations
- **Palette**: near-black surfaces (`#000`→`#232323` layered scale) with a single warm gold accent (`#B7A024`, hover-lighter `#D9C34F`). Gold is a *punctuation* colour: primary CTA, active states, prices, the "MA" in the wordmark — never a full-panel wash or background gradient.
- **Type**: Inter (400–800), loaded from Google Fonts. Display/heading sizes use tight (−0.02em) tracking; uppercase micro-labels use wide tracking. No serif anywhere.
- **Cards & surfaces**: flat `surface-2` panels, 1px low-contrast border, 8–12px radius. Refinement from source: dropped the `::before` diagonal gradient overlays, the coloured glow shadows, and the `translateY(-8px)` hover lift that appeared on nearly every card in the original CSS — hover is now just a border-brighten.
- **Buttons**: one solid gold primary CTA per screen; everything else is outline or ghost. No gradient-fill buttons (source used a 135° gold gradient on every primary button and card-header text) — solid gold reads cleaner at small sizes and is easier to keep accessible.
- **Radii**: 6/8/12/16px scale. Source frequently used 16–20px on cards; this system caps ordinary cards at 12px and reserves 16px for large modals/hero panels only.
- **Shadows**: neutral, low-opacity, used sparingly (`shadow-sm`/`md`/`lg`). A gold-tinted shadow exists (`shadow-gold`) but is reserved for the primary CTA hover only — never ambient on cards.
- **Motion**: 120–280ms, `cubic-bezier(0.4,0,0.2,1)`. Hover/press communicate via colour and border, not scale or translateY bounces.
- **Imagery**: no photography or illustration was supplied. The product is inherently visual (3D models) — screens use a placeholder 3D-viewport panel where a live model render belongs; do not invent illustrations for it.
- **Backgrounds**: flat colour only. No gradients-as-background, no decorative blur, no repeating patterns/textures in this refined system (the source used `backdrop-filter: blur()` on nearly every section — dropped, it added visual noise without a real glass surface behind it).
- **Transparency**: none used decoratively; the only translucency is semantic (colour "wash" tokens = solid colour at low opacity, for badges/status chips/dropzone active state).

## Iconography
The codebase uses **lucide-react** (`lucide-react ^0.294.0`) exclusively — no icon font, no custom SVG set, no emoji-as-icon. This system loads the same library from CDN (`unpkg.com/lucide@0.294.0`) for UI-kit screens, and documents its use rather than hand-drawing substitutes. Stroke icons only, 2px stroke, no filled icon style.

## Logo
Provided as pre-rendered PNG lockups (no source SVG/vector was supplied): wordmark "PRINT" (black or white) + "MA" (always gold) plus "3D Print Solutions" subline, in square and circular crops, on black/white/transparent. Stored in `assets/logo/`. Always keep "MA" in gold — it is the one fixed brand-colour rule in every variant supplied. No standalone icon-only mark exists beyond the circular lockup crops.

## Components (`components/`)
No component library or Figma file was attached, so this system authors a standard set **sized to what the product actually uses** (cross-checked against the real screens, not invented from a generic template):
- `core/` — **Button**, **Badge**, **Card**
- `forms/` — **Input**, **Select**
- `feedback/` — **Toast**, **ProgressSteps**
- `commerce/` — **ColorSwatch**, **PriceSummary**, **Dropzone** (product-specific: filament colour picker, price breakdown, STL upload target)

## UI kit (`ui_kits/konfigurator/`)
Interactive click-through recreation of the configurator's five-step flow (`Upload → Konfiguration → Übersicht → Bestellung → Abschluss`), matching `ConfiguratorPage.jsx`'s real step machine, composed entirely from the components above plus shared `Header`/`Footer`. Secondary marketing pages (Material, Dienstleistungen, FAQ) were not rebuilt as full screens — flagged below for follow-up.

## Tokens (`tokens/`)
`colors.css`, `typography.css`, `spacing.css`, `effects.css` — imported by root `styles.css`. Inter is loaded via a Google Fonts `@import` (matches how the source app loads it; no font files were bundled in the codebase to copy locally).

## Index
- `styles.css` — root stylesheet, import-only
- `tokens/` — colors, typography, spacing, effects
- `base.css` — global reset/body defaults
- `assets/logo/` — all supplied logo crops + favicon
- `guidelines/` — 12 foundation specimen cards (Colors, Type, Spacing, Brand)
- `components/core|forms|feedback|commerce/` — 10 components, each with `.jsx` + `.d.ts` + `.prompt.md` + a card
- `ui_kits/konfigurator/` — interactive 5-step configurator recreation
- `thumbnail.html` — project tile

## Caveats & ask
1. **No vector logo, no Figma, no font files** were provided — logo is PNG-only (fine for docs/UI, not for large-format print), Inter is CDN-loaded rather than self-hosted, and every screen is rebuilt from CSS/JSX rather than a design tool source of truth. If you have the original AI/SVG logo, a Figma file, or self-hostable Inter woff2 files, share them and I'll upgrade these.
2. **Only the configurator flow got a full UI kit.** Material/Dienstleistungen/FAQ/legal pages exist in the codebase but weren't rebuilt as screens — say the word and I'll add them.
3. The "de-plumped" visual direction (flatter cards, solid CTA, no glow/blur) is my interpretation of "professionell und clean" — **tell me if any specific screen should stay closer to the current live gradients/glow**, and I'll adjust the tokens rather than the whole system.

Iterate with me — call out any card, component, or screen above and I'll refine it.
