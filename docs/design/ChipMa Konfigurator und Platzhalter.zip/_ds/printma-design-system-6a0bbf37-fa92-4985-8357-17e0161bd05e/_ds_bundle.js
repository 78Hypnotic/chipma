/* @ds-bundle: {"format":4,"namespace":"PrintMaDesignSystem_6a0bbf","components":[{"name":"ColorSwatch","sourcePath":"components/commerce/ColorSwatch.jsx"},{"name":"Dropzone","sourcePath":"components/commerce/Dropzone.jsx"},{"name":"PriceSummary","sourcePath":"components/commerce/PriceSummary.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"ProgressSteps","sourcePath":"components/feedback/ProgressSteps.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"}],"sourceHashes":{"components/commerce/ColorSwatch.jsx":"d5c68cb6ce18","components/commerce/Dropzone.jsx":"caa1a5f682f9","components/commerce/PriceSummary.jsx":"f94f4f373509","components/core/Badge.jsx":"6e840e25763d","components/core/Button.jsx":"2165597a5ff4","components/core/Card.jsx":"0e22a4ee5864","components/feedback/ProgressSteps.jsx":"711600930f8d","components/feedback/Toast.jsx":"b1d515cd8482","components/forms/Input.jsx":"76dcc8061065","components/forms/Select.jsx":"560dabc2c806","ui_kits/konfigurator/App.jsx":"a04eaba5823f","ui_kits/konfigurator/Footer.jsx":"94dcebbef3b5","ui_kits/konfigurator/Header.jsx":"68e178657807","ui_kits/konfigurator/screens/CompleteScreen.jsx":"f3e79162e686","ui_kits/konfigurator/screens/ConfigureScreen.jsx":"611f61601e74","ui_kits/konfigurator/screens/OrderScreen.jsx":"39a67d2da1d8","ui_kits/konfigurator/screens/ReviewScreen.jsx":"e63267bcec3a","ui_kits/konfigurator/screens/UploadScreen.jsx":"4127e913f0dc"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PrintMaDesignSystem_6a0bbf = window.PrintMaDesignSystem_6a0bbf || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/commerce/ColorSwatch.jsx
try { (() => {
function ColorSwatch({
  colors,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(64px, 1fr))',
      gap: 10,
      fontFamily: 'var(--font-sans)'
    }
  }, colors.map(c => {
    const active = value === c.name;
    return /*#__PURE__*/React.createElement("button", {
      key: c.name,
      onClick: () => onChange && onChange(c.name),
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 6,
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: 6,
        borderRadius: 'var(--radius-md)',
        outline: active ? '1px solid var(--gold)' : '1px solid transparent'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 32,
        height: 32,
        borderRadius: '50%',
        background: c.hex,
        border: '1px solid var(--border-strong)',
        boxShadow: active ? '0 0 0 3px var(--gold-wash)' : 'none'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-micro)',
        color: active ? 'var(--text-primary)' : 'var(--text-tertiary)'
      }
    }, c.name));
  }));
}
Object.assign(__ds_scope, { ColorSwatch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/ColorSwatch.jsx", error: String((e && e.message) || e) }); }

// components/commerce/Dropzone.jsx
try { (() => {
function Dropzone({
  active = false,
  title = 'Dateien hier ablegen',
  subtitle = 'oder klicken zum Auswählen',
  hint,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  const on = active || hover;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      border: `1.5px dashed ${on ? 'var(--gold)' : 'var(--border-strong)'}`,
      borderRadius: 'var(--radius-lg)',
      padding: '48px 24px',
      textAlign: 'center',
      cursor: 'pointer',
      background: on ? 'var(--gold-wash)' : 'var(--surface-1)',
      transition: 'all var(--duration-base) var(--ease-standard)',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: on ? 'var(--gold)' : 'var(--text-tertiary)',
      marginBottom: 16,
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "32",
    height: "32",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 3v12m0-12 4 4m-4-4-4 4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-primary)',
      fontSize: 'var(--text-h4)',
      fontWeight: 600,
      marginBottom: 6
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-body)'
    }
  }, subtitle), hint && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      display: 'inline-block',
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-small)',
      background: 'var(--surface-3)',
      padding: '8px 16px',
      borderRadius: 'var(--radius-md)'
    }
  }, hint));
}
Object.assign(__ds_scope, { Dropzone });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/Dropzone.jsx", error: String((e && e.message) || e) }); }

// components/commerce/PriceSummary.jsx
try { (() => {
function PriceSummary({
  items = [],
  total,
  note
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-2)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      padding: 24,
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      marginBottom: 16
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-body)'
    }
  }, it.label), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-primary)',
      fontSize: 'var(--text-body)',
      fontWeight: 500
    }
  }, it.value)))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      paddingTop: 16,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-primary)',
      fontSize: 'var(--text-h4)',
      fontWeight: 600
    }
  }, "Gesamtpreis"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--gold)',
      fontSize: 'var(--text-h2)',
      fontWeight: 700
    }
  }, total)), note && /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-small)',
      margin: '10px 0 0'
    }
  }, note));
}
Object.assign(__ds_scope, { PriceSummary });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/PriceSummary.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
const toneMap = {
  neutral: {
    bg: 'var(--surface-3)',
    fg: 'var(--text-secondary)'
  },
  gold: {
    bg: 'var(--gold-wash)',
    fg: 'var(--gold-300)'
  },
  success: {
    bg: 'var(--success-wash)',
    fg: 'var(--success)'
  },
  warning: {
    bg: 'var(--warning-wash)',
    fg: 'var(--warning)'
  },
  error: {
    bg: 'var(--error-wash)',
    fg: 'var(--error)'
  }
};
function Badge({
  tone = 'neutral',
  children
}) {
  const t = toneMap[tone] || toneMap.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      height: 20,
      padding: '0 9px',
      borderRadius: 'var(--radius-full)',
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-micro)',
      fontWeight: 600,
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      whiteSpace: 'nowrap'
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizeMap = {
  sm: {
    h: 32,
    px: 12,
    fs: 'var(--text-small)'
  },
  md: {
    h: 40,
    px: 18,
    fs: 'var(--text-body)'
  },
  lg: {
    h: 48,
    px: 24,
    fs: 'var(--text-body-lg)'
  }
};
function variantStyle(variant) {
  switch (variant) {
    case 'primary':
      return {
        background: 'var(--gold)',
        color: 'var(--text-on-gold)',
        border: '1px solid transparent'
      };
    case 'secondary':
      return {
        background: 'transparent',
        color: 'var(--text-primary)',
        border: '1px solid var(--border-strong)'
      };
    case 'ghost':
      return {
        background: 'transparent',
        color: 'var(--text-secondary)',
        border: '1px solid transparent'
      };
    case 'destructive':
      return {
        background: 'transparent',
        color: 'var(--error)',
        border: '1px solid var(--error)'
      };
    default:
      return {};
  }
}
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  icon = null,
  children,
  onClick,
  style,
  ...rest
}) {
  const s = sizeMap[size] || sizeMap.md;
  const [hover, setHover] = React.useState(false);
  const base = variantStyle(variant);
  const hoverBg = {
    primary: 'var(--gold-300)',
    secondary: 'var(--surface-2)',
    ghost: 'var(--surface-2)',
    destructive: 'var(--error-wash)'
  }[variant];
  return /*#__PURE__*/React.createElement("button", _extends({
    onClick: onClick,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      height: s.h,
      padding: `0 ${s.px}px`,
      fontSize: s.fs,
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'background var(--duration-base) var(--ease-standard), border-color var(--duration-base) var(--ease-standard)',
      ...base,
      ...(hover && !disabled ? {
        background: hoverBg,
        borderColor: variant === 'secondary' ? 'var(--gold)' : base.border
      } : {}),
      ...style
    }
  }, rest), icon, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function Card({
  hoverable = false,
  padding = 24,
  children,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => hoverable && setHover(true),
    onMouseLeave: () => hoverable && setHover(false),
    style: {
      background: 'var(--surface-2)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      padding,
      transition: 'border-color var(--duration-base) var(--ease-standard)',
      borderColor: hover ? 'var(--border-strong)' : 'var(--border-subtle)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ProgressSteps.jsx
try { (() => {
function ProgressSteps({
  steps,
  currentIndex = 0
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      fontFamily: 'var(--font-sans)'
    }
  }, steps.map((label, i) => {
    const state = i < currentIndex ? 'done' : i === currentIndex ? 'active' : 'upcoming';
    const textColor = state === 'upcoming' ? 'var(--text-tertiary)' : state === 'active' ? 'var(--text-primary)' : 'var(--text-secondary)';
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: label
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 6,
        height: 6,
        borderRadius: '50%',
        background: state === 'upcoming' ? 'var(--border-strong)' : 'var(--gold)',
        flexShrink: 0
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-small)',
        fontWeight: state === 'active' ? 600 : 500,
        color: textColor,
        whiteSpace: 'nowrap',
        letterSpacing: 'var(--tracking-normal)'
      }
    }, label)), i < steps.length - 1 && /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--border-subtle)',
        margin: '0 20px'
      }
    }));
  }));
}
Object.assign(__ds_scope, { ProgressSteps });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ProgressSteps.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const toneMap = {
  success: {
    border: 'var(--success)',
    bg: 'var(--surface-2)'
  },
  error: {
    border: 'var(--error)',
    bg: 'var(--surface-2)'
  },
  warning: {
    border: 'var(--warning)',
    bg: 'var(--surface-2)'
  },
  info: {
    border: 'var(--info)',
    bg: 'var(--surface-2)'
  }
};
function Toast({
  tone = 'info',
  message,
  onClose
}) {
  const t = toneMap[tone] || toneMap.info;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '14px 16px',
      background: t.bg,
      borderLeft: `3px solid ${t.border}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-md)',
      minWidth: 280,
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: t.border,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      color: 'var(--text-primary)',
      fontSize: 'var(--text-body)'
    }
  }, message), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      background: 'none',
      border: 'none',
      color: 'var(--text-tertiary)',
      cursor: 'pointer',
      fontSize: 16,
      lineHeight: 1
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  icon = null,
  error = null,
  type = 'text',
  placeholder,
  value,
  onChange,
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      fontFamily: 'var(--font-sans)'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-small)',
      fontWeight: 600,
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 12,
      color: 'var(--text-tertiary)',
      display: 'flex'
    }
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      width: '100%',
      height: 44,
      padding: icon ? '0 14px 0 40px' : '0 14px',
      background: 'var(--surface-2)',
      color: 'var(--text-primary)',
      border: `1px solid ${error ? 'var(--error)' : focused ? 'var(--gold)' : 'var(--border)'}`,
      borderRadius: 'var(--radius-md)',
      fontSize: 'var(--text-body)',
      fontFamily: 'inherit',
      outline: 'none',
      transition: 'border-color var(--duration-base) var(--ease-standard)'
    }
  }, rest))), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-small)',
      color: 'var(--error)'
    }
  }, error));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  value,
  onChange,
  options = [],
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      fontFamily: 'var(--font-sans)'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-small)',
      fontWeight: 600,
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    onChange: onChange,
    style: {
      width: '100%',
      height: 44,
      padding: '0 40px 0 14px',
      appearance: 'none',
      background: 'var(--surface-2)',
      color: 'var(--text-primary)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)',
      fontSize: 'var(--text-body)',
      fontFamily: 'inherit',
      outline: 'none',
      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23b7a024' d='M6 8L1 3h10z'/%3E%3C/svg%3E\")",
      backgroundRepeat: 'no-repeat',
      backgroundPosition: 'right 14px center'
    }
  }, rest), options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label)))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// ui_kits/konfigurator/App.jsx
try { (() => {
function App() {
  const [step, setStep] = React.useState('upload');
  const steps = ['upload', 'configure', 'review', 'order', 'complete'];
  const labels = ['Upload', 'Konfiguration', 'Übersicht', 'Bestellung', 'Abschluss'];
  const {
    ProgressSteps
  } = window.PrintMaDesignSystem_6a0bbf;
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-0)'
    }
  }, /*#__PURE__*/React.createElement(Header, null), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-1)',
      borderBottom: '1px solid var(--border-subtle)',
      padding: '16px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(ProgressSteps, {
    steps: labels,
    currentIndex: steps.indexOf(step)
  }))), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1
    }
  }, step === 'upload' && /*#__PURE__*/React.createElement(UploadScreen, {
    onUpload: () => setStep('configure')
  }), step === 'configure' && /*#__PURE__*/React.createElement(ConfigureScreen, {
    onBack: () => setStep('upload'),
    onAddToCart: () => setStep('review')
  }), step === 'review' && /*#__PURE__*/React.createElement(ReviewScreen, {
    onBack: () => setStep('configure'),
    onContinue: () => setStep('order')
  }), step === 'order' && /*#__PURE__*/React.createElement(OrderScreen, {
    onBack: () => setStep('review'),
    onSubmit: () => setStep('complete')
  }), step === 'complete' && /*#__PURE__*/React.createElement(CompleteScreen, {
    onRestart: () => setStep('upload')
  })), /*#__PURE__*/React.createElement(Footer, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/konfigurator/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/konfigurator/Footer.jsx
try { (() => {
function Footer() {
  const col = {
    display: 'flex',
    flexDirection: 'column',
    gap: 12
  };
  const h4 = {
    color: 'var(--gold)',
    fontSize: 'var(--text-small)',
    fontWeight: 700,
    letterSpacing: 'var(--tracking-wide)',
    textTransform: 'uppercase',
    margin: '0 0 4px'
  };
  const link = {
    color: 'var(--text-secondary)',
    fontSize: 'var(--text-body)',
    display: 'flex',
    alignItems: 'center',
    gap: 8
  };
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--surface-1)',
      borderTop: '1px solid var(--border-subtle)',
      marginTop: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1240,
      margin: '0 auto',
      padding: '48px 32px',
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo/printma-lockup-transparent-white-text.png",
    style: {
      height: 26,
      width: 'auto',
      alignSelf: 'flex-start',
      marginBottom: 4
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-primary)',
      fontWeight: 600
    }
  }, "PrintMa GbR"), /*#__PURE__*/React.createElement("div", {
    style: link
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "map-pin",
    width: "15",
    height: "15"
  }), " Randenstr. 8, 78234 Engen"), /*#__PURE__*/React.createElement("div", {
    style: link
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "mail",
    width: "15",
    height: "15"
  }), " printmagbr@gmail.com")), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement("h4", {
    style: h4
  }, "Navigation"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "file-text",
    width: "15",
    height: "15"
  }), " 3D-Konfigurator"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "package",
    width: "15",
    height: "15"
  }), " Bestellstatus"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "help-circle",
    width: "15",
    height: "15"
  }), " FAQ")), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement("h4", {
    style: h4
  }, "Rechtliches"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, "Datenschutzerkl\xE4rung"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, "AGB"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, "Widerrufsbelehrung"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, "Impressum")), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement("h4", {
    style: h4
  }, "Services"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-body)'
    }
  }, "3D-Druck Service"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-body)'
    }
  }, "Prototyping"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-body)'
    }
  }, "Kleinserien"))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      padding: '16px 32px',
      textAlign: 'center',
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-small)'
    }
  }, "\xA9 ", new Date().getFullYear(), " PrintMa GbR. Alle Rechte vorbehalten."));
}
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/konfigurator/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/konfigurator/Header.jsx
try { (() => {
function Header({
  step
}) {
  const linkStyle = active => ({
    padding: '8px 4px',
    fontSize: 'var(--text-small)',
    fontWeight: 500,
    background: 'none',
    color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
    border: 'none',
    borderBottom: active ? '2px solid var(--gold)' : '2px solid transparent',
    cursor: 'pointer'
  });
  const {
    Button
  } = window.PrintMaDesignSystem_6a0bbf;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      background: 'var(--surface-0)',
      borderBottom: '1px solid var(--border-subtle)',
      position: 'sticky',
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1240,
      margin: '0 auto',
      padding: '18px 32px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo/printma-lockup-transparent-white-text.png",
    alt: "PrintMa",
    style: {
      height: 28,
      width: 'auto'
    }
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 28,
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: linkStyle(true)
  }, "Konfigurator"), /*#__PURE__*/React.createElement("button", {
    style: linkStyle(false)
  }, "Dienstleistungen"), /*#__PURE__*/React.createElement("button", {
    style: linkStyle(false)
  }, "Material")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "Anmelden"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm"
  }, "Registrieren"))));
}
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/konfigurator/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/konfigurator/screens/CompleteScreen.jsx
try { (() => {
function CompleteScreen({
  onRestart
}) {
  const {
    Button
  } = window.PrintMaDesignSystem_6a0bbf;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 560,
      margin: '0 auto',
      padding: '96px 32px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 64,
      height: 64,
      borderRadius: '50%',
      background: 'var(--success-wash)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      margin: '0 auto 24px'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check-circle",
    width: "30",
    height: "30",
    style: {
      color: 'var(--success)'
    }
  })), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-h1)',
      color: 'var(--text-primary)',
      margin: '0 0 12px'
    }
  }, "Bestellung erfolgreich!"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-body-lg)',
      margin: '0 0 8px'
    }
  }, "Bestellnummer ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--text-primary)'
    }
  }, "#PM-20394")), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-tertiary)',
      margin: '0 0 32px'
    }
  }, "Eine Best\xE4tigung wurde an Ihre E-Mail-Adresse gesendet. Die meisten Bestellungen sind innerhalb von 2\u20135 Werktagen bei Ihnen."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onRestart
  }, "Neue Bestellung starten"));
}
window.CompleteScreen = CompleteScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/konfigurator/screens/CompleteScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/konfigurator/screens/ConfigureScreen.jsx
try { (() => {
function ConfigureScreen({
  onBack,
  onAddToCart
}) {
  const {
    Card,
    Select,
    ColorSwatch,
    PriceSummary,
    Button
  } = window.PrintMaDesignSystem_6a0bbf;
  const [material, setMaterial] = React.useState('PLA');
  const [color, setColor] = React.useState('Schwarz');
  const colors = [{
    name: 'Schwarz',
    hex: '#111'
  }, {
    name: 'Weiß',
    hex: '#fff'
  }, {
    name: 'Grau',
    hex: '#8E9089'
  }, {
    name: 'Blau',
    hex: '#0A2989'
  }, {
    name: 'Rot',
    hex: '#C12E1F'
  }, {
    name: 'Gelb',
    hex: '#F4EE2A'
  }, {
    name: 'Grün',
    hex: '#22c55e'
  }, {
    name: 'Orange',
    hex: '#f97316'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '40px 32px',
      display: 'grid',
      gridTemplateColumns: '1fr 420px',
      gap: 32,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: 0,
    style: {
      height: 420,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "box",
    width: "48",
    height: "48"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 'var(--text-small)'
    }
  }, "3D-Modell-Vorschau"))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 6px',
      color: 'var(--text-primary)',
      fontSize: 'var(--text-h4)'
    }
  }, "halterung_v3.stl"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-small)'
    }
  }, "84 \xD7 42 \xD7 18 mm \xB7 12.4 cm\xB3"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Material",
    value: material,
    onChange: e => setMaterial(e.target.value),
    options: ['PLA', 'PETG', 'TPU', 'ASA', 'ABS', 'ABS-GF'].map(m => ({
      value: m,
      label: m
    }))
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-small)',
      fontWeight: 600,
      color: 'var(--text-primary)',
      marginBottom: 10
    }
  }, "Farbe"), /*#__PURE__*/React.createElement(ColorSwatch, {
    colors: colors,
    value: color,
    onChange: setColor
  })), /*#__PURE__*/React.createElement(Select, {
    label: "Schichth\xF6he",
    value: "0.2",
    onChange: () => {},
    options: [{
      value: '0.1',
      label: '0.1 mm — hohe Qualität'
    }, {
      value: '0.2',
      label: '0.2 mm — Standard'
    }, {
      value: '0.3',
      label: '0.3 mm — schnell'
    }]
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Infill",
    value: "20",
    onChange: () => {},
    options: [{
      value: '10',
      label: '10 %'
    }, {
      value: '20',
      label: '20 %'
    }, {
      value: '50',
      label: '50 %'
    }, {
      value: '100',
      label: '100 %'
    }]
  }))), /*#__PURE__*/React.createElement(PriceSummary, {
    items: [{
      label: 'Material (PLA)',
      value: '€4.20'
    }, {
      label: 'Einrichtungsgebühr',
      value: '€5.00'
    }],
    total: "\u20AC9.20",
    note: "Inkl. MwSt., zzgl. Versand"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: onBack,
    style: {
      flex: 1
    }
  }, "Zur\xFCck"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onAddToCart,
    style: {
      flex: 2
    }
  }, "In den Warenkorb (1 Teil)"))));
}
window.ConfigureScreen = ConfigureScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/konfigurator/screens/ConfigureScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/konfigurator/screens/OrderScreen.jsx
try { (() => {
function OrderScreen({
  onBack,
  onSubmit
}) {
  const {
    Card,
    Input,
    Select,
    PriceSummary,
    Button
  } = window.PrintMaDesignSystem_6a0bbf;
  const [payment, setPayment] = React.useState('card');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '40px 32px',
      display: 'grid',
      gridTemplateColumns: '1fr 380px',
      gap: 32,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-h1)',
      color: 'var(--text-primary)',
      margin: 0
    }
  }, "Bestellung abschlie\xDFen"), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Vorname",
    placeholder: "Max"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Nachname",
    placeholder: "Mustermann"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1 / -1'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "E-Mail",
    placeholder: "max@beispiel.de"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1 / -1'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Stra\xDFe & Hausnummer",
    placeholder: "Musterstra\xDFe 1"
  })), /*#__PURE__*/React.createElement(Input, {
    label: "PLZ",
    placeholder: "78234"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Ort",
    placeholder: "Engen"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1 / -1'
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Land",
    value: "DE",
    onChange: () => {},
    options: [{
      value: 'DE',
      label: 'Deutschland'
    }, {
      value: 'AT',
      label: 'Österreich'
    }, {
      value: 'CH',
      label: 'Schweiz'
    }]
  })))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-small)',
      fontWeight: 600,
      color: 'var(--text-primary)',
      marginBottom: 12
    }
  }, "Zahlungsmethode"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, [['card', 'credit-card', 'Kreditkarte'], ['paypal', 'wallet', 'PayPal']].map(([id, icon, label]) => /*#__PURE__*/React.createElement("div", {
    key: id,
    onClick: () => setPayment(id),
    style: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      border: `1px solid ${payment === id ? 'var(--gold)' : 'var(--border-subtle)'}`,
      background: payment === id ? 'var(--gold-wash)' : 'var(--surface-2)',
      borderRadius: 'var(--radius-md)',
      padding: '14px 16px'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": icon,
    width: "18",
    height: "18",
    style: {
      color: payment === id ? 'var(--gold)' : 'var(--text-tertiary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-primary)',
      fontSize: 'var(--text-body)'
    }
  }, label)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(PriceSummary, {
    items: [{
      label: '1 × halterung_v3.stl',
      value: '€9.20'
    }, {
      label: 'Versand',
      value: '€4.90'
    }],
    total: "\u20AC14.10",
    note: "Inkl. MwSt."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: onBack
  }, "Zur\xFCck"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onSubmit,
    style: {
      flex: 1
    }
  }, "Jetzt kostenpflichtig bestellen"))));
}
window.OrderScreen = OrderScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/konfigurator/screens/OrderScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/konfigurator/screens/ReviewScreen.jsx
try { (() => {
function ReviewScreen({
  onBack,
  onContinue
}) {
  const {
    Card,
    Badge,
    PriceSummary,
    Button
  } = window.PrintMaDesignSystem_6a0bbf;
  const [qty, setQty] = React.useState(1);
  const [shipping, setShipping] = React.useState('pickup');
  const options = [{
    id: 'pickup',
    label: 'Selbstabholung',
    desc: 'Engen · kostenlos'
  }, {
    id: 'standard',
    label: 'Standardversand',
    desc: '3–5 Werktage · €4.90'
  }, {
    id: 'express',
    label: 'Expressversand',
    desc: '1–2 Werktage · €12.90'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-narrow)',
      margin: '0 auto',
      padding: '40px 32px',
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-h1)',
      color: 'var(--text-primary)',
      margin: 0
    }
  }, "\xDCbersicht"), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 64,
      height: 64,
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-3)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "box",
    width: "24",
    height: "24",
    style: {
      color: 'var(--text-tertiary)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-primary)',
      fontWeight: 600,
      marginBottom: 6
    }
  }, "halterung_v3.stl"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, "PLA"), /*#__PURE__*/React.createElement(Badge, {
    tone: "gold"
  }, "Schwarz"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setQty(Math.max(1, qty - 1)),
    style: {
      width: 28,
      height: 28,
      borderRadius: 'var(--radius-sm)',
      border: '1px solid var(--border)',
      background: 'var(--surface-2)',
      color: 'var(--text-primary)',
      cursor: 'pointer'
    }
  }, "\u2212"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-primary)',
      minWidth: 16,
      textAlign: 'center'
    }
  }, qty), /*#__PURE__*/React.createElement("button", {
    onClick: () => setQty(qty + 1),
    style: {
      width: 28,
      height: 28,
      borderRadius: 'var(--radius-sm)',
      border: '1px solid var(--border)',
      background: 'var(--surface-2)',
      color: 'var(--text-primary)',
      cursor: 'pointer'
    }
  }, "+")), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--gold)',
      fontWeight: 700,
      minWidth: 60,
      textAlign: 'right'
    }
  }, "\u20AC9.20"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-small)',
      fontWeight: 600,
      color: 'var(--text-primary)',
      marginBottom: 10
    }
  }, "Versand"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 12
    }
  }, options.map(o => /*#__PURE__*/React.createElement("div", {
    key: o.id,
    onClick: () => setShipping(o.id),
    style: {
      cursor: 'pointer',
      border: `1px solid ${shipping === o.id ? 'var(--gold)' : 'var(--border-subtle)'}`,
      background: shipping === o.id ? 'var(--gold-wash)' : 'var(--surface-2)',
      borderRadius: 'var(--radius-md)',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-primary)',
      fontWeight: 600,
      fontSize: 'var(--text-small)'
    }
  }, o.label), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-micro)',
      marginTop: 4
    }
  }, o.desc))))), /*#__PURE__*/React.createElement(PriceSummary, {
    items: [{
      label: `${qty} × halterung_v3.stl`,
      value: `€${(9.2 * qty).toFixed(2)}`
    }, {
      label: 'Versand',
      value: shipping === 'pickup' ? '€0.00' : shipping === 'standard' ? '€4.90' : '€12.90'
    }],
    total: `€${(9.2 * qty + (shipping === 'pickup' ? 0 : shipping === 'standard' ? 4.9 : 12.9)).toFixed(2)}`,
    note: "Inkl. MwSt."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: onBack,
    style: {
      flex: 1
    }
  }, "Zur\xFCck zur Konfiguration"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onContinue,
    style: {
      flex: 2
    }
  }, "Weiter zur Bestellung")));
}
window.ReviewScreen = ReviewScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/konfigurator/screens/ReviewScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/konfigurator/screens/UploadScreen.jsx
try { (() => {
function UploadScreen({
  onUpload
}) {
  const {
    Card
  } = window.PrintMaDesignSystem_6a0bbf;
  const features = [['printer', 'Professioneller 3D-Druck', 'Hochwertige FDM-Drucke mit modernster Technologie für präzise Ergebnisse.'], ['palette', 'Vielfältige Materialien', 'Von PLA über PETG bis TPU — große Auswahl an hochwertigen Filamenten.'], ['cog', 'CAD-Konstruktion', 'Professionelle Konstruktion für individuelle Anforderungen und Projekte.'], ['shield', 'Qualitätsgarantie', 'Jedes Druckteil wird sorgfältig geprüft und entspricht höchsten Standards.']];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '72px 32px',
      display: 'flex',
      flexDirection: 'column',
      gap: 88
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 36
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-display)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-primary)',
      margin: '0 0 14px'
    }
  }, "STL-Datei hochladen"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-body-lg)',
      margin: 0
    }
  }, "Laden Sie Ihr 3D-Modell hoch und konfigurieren Sie Material, Farbe und Menge.")), /*#__PURE__*/React.createElement("div", {
    onClick: onUpload,
    style: {
      maxWidth: 640,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1.5px dashed var(--border-strong)',
      borderRadius: 'var(--radius-lg)',
      padding: '48px 24px',
      textAlign: 'center',
      cursor: 'pointer',
      background: 'var(--surface-1)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "upload",
    width: "32",
    height: "32",
    style: {
      color: 'var(--text-tertiary)',
      marginBottom: 16
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-primary)',
      fontSize: 'var(--text-h4)',
      fontWeight: 600,
      marginBottom: 6
    }
  }, "Dateien hier ablegen"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-secondary)'
    }
  }, "oder klicken zum Ausw\xE4hlen"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      display: 'inline-block',
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-small)',
      background: 'var(--surface-3)',
      padding: '8px 16px',
      borderRadius: 'var(--radius-md)'
    }
  }, "Max. 50 MB \xB7 STL, OBJ, AMF, PLY, STEP")))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      textAlign: 'center',
      fontSize: 'var(--text-h2)',
      fontWeight: 700,
      color: 'var(--text-primary)',
      margin: '0 0 40px'
    }
  }, "Warum PrintMa f\xFCr Ihren 3D-Druck?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 20
    }
  }, features.map(([icon, title, desc]) => /*#__PURE__*/React.createElement(Card, {
    key: title
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": icon,
    width: "26",
    height: "26",
    style: {
      color: 'var(--gold)',
      marginBottom: 14
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--text-h4)',
      color: 'var(--text-primary)',
      margin: '0 0 8px'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-small)',
      margin: 0,
      lineHeight: 'var(--lh-normal)'
    }
  }, desc))))));
}
window.UploadScreen = UploadScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/konfigurator/screens/UploadScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.ColorSwatch = __ds_scope.ColorSwatch;

__ds_ns.Dropzone = __ds_scope.Dropzone;

__ds_ns.PriceSummary = __ds_scope.PriceSummary;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.ProgressSteps = __ds_scope.ProgressSteps;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

})();
